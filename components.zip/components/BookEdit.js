import { useState } from "react";
function BookEdit({book,onSubmit}){

    const [title, settitle] = useState(book.title)

    const handleChange=(event)=>{
        settitle(event.target.value)
    }

    const handleSubmit=(e)=>{
        e.preventDefault()
        onSubmit(book.id,title)

    }

    return (
        <>
        <div>
            <form onSubmit={handleSubmit}>
                <label>Title</label>
                <input type="text"  className="input" value={title} onChange={handleChange}/>
                <button className="button is-primary">Edit</button>
            </form>
        </div>
        </>
    )
}

export default BookEdit;