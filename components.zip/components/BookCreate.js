import { useState } from "react";

function BookCreate({onCreate}){
    const [title, settitle] = useState('')

    const handleSubmit = (e) =>{
        e.preventDefault();
        onCreate(title)
        settitle('')
    }

    const onInputChange = (event)=>{
        settitle(event.target.value)
       
    }

    return (
        <>
        <div className="book-create">
            <h3>Add a Book</h3>
            <form onSubmit={handleSubmit}>
            <input className="input" value={title} onChange={onInputChange}/>
            <button className="button" >Submit</button>
            </form>
        </div>
        
        </>
    )
}

export default BookCreate;