import './App.css';
import BookCreate from './components/BookCreate';
import { useState,useEffect } from 'react';
import BookList from './components/BookList'
import axios from 'axios';

function App() {

  const [books, setbooks] = useState([])

  const FetchBooks= async ()=>{
    const response = await axios.get('http://127.0.0.1:3001/books')
    setbooks(response.data)
  }

  useEffect(()=>{
    FetchBooks()
  },[])

  const EditBookById= async (id,newTitle)=>{
    const response = await axios.put(`http://127.0.0.1:3001/books/${id}`,{
      title:newTitle

    })

    const updatedBooks=books.map((book)=>{
      if(book.id===id){
        return {...book,...response.data}
      }
      return book
    })
    setbooks(updatedBooks)
  }

  const DeleteBookById= async (id)=>{
    await axios.delete(`http://127.0.0.1:3001/books/${id}`)
    
    const updatedBooks=books.filter((book)=>{
      return book.id !== id
    })
    setbooks(updatedBooks)
  }

  const CreateBook= async (title)=>{
    const response = await axios.post('http://127.0.0.1:3001/books',{
      title:title
    })
    console.log(response);
    const updatedBooks=[
      ...books,{id:Math.floor(Math.random()*20),title:title}
    ]
    setbooks(updatedBooks)
  }

  return (
    <>
    <div>
      <BookList books={books} onDelete={DeleteBookById} onEdit={EditBookById} />
      <BookCreate onCreate={CreateBook} />
    </div>
    </>
  );
}

export default App;
